import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ArrowDown } from 'lucide-react';

interface SequenceStep {
  actor: string;
  component: string;
  action: string;
  data: string;
  time: string;
}

interface SequenceDiagramProps {
  steps: SequenceStep[];
  title: string;
}

export const SequenceDiagram: React.FC<SequenceDiagramProps> = ({ steps, title }) => {
  const getActorColor = (actor: string) => {
    if (actor === 'Student') return 'blue';
    if (actor === 'Human Operator') return 'orange';
    if (actor === 'Misty') return 'purple';
    return 'gray';
  };

  return (
    <Card className="p-6">
      <h4 className="mb-4 text-gray-900">{title}</h4>
      <div className="space-y-2">
        {steps.map((step, idx) => (
          <div key={idx}>
            <div className="flex items-start gap-4">
              <Badge className="min-w-[60px] text-xs">{step.time}</Badge>
              <div className="flex-1 grid grid-cols-3 gap-4 items-start">
                <Badge 
                  variant="outline"
                  className={`bg-${getActorColor(step.actor)}-50 border-${getActorColor(step.actor)}-300`}
                >
                  {step.actor}
                </Badge>
                <Badge variant="secondary" className="text-xs">
                  {step.component}
                </Badge>
                <div>
                  <p className="text-sm text-gray-900">{step.action}</p>
                  <p className="text-xs text-gray-500 mt-1">{step.data}</p>
                </div>
              </div>
            </div>
            {idx < steps.length - 1 && (
              <div className="ml-20 my-1">
                <ArrowDown className="w-4 h-4 text-gray-400" />
              </div>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
};
