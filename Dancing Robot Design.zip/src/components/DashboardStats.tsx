import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  icon: LucideIcon;
  label: string;
  value: string;
  color: string;
  description?: string;
}

export const StatCard: React.FC<StatCardProps> = ({ icon: Icon, label, value, color, description }) => {
  return (
    <Card className={`p-4 border-2 bg-${color}-50 border-${color}-200`}>
      <div className="flex items-start justify-between mb-2">
        <div className={`p-2 rounded-lg bg-${color}-100`}>
          <Icon className={`w-5 h-5 text-${color}-600`} />
        </div>
        <Badge variant="outline" className="text-xs">
          {label}
        </Badge>
      </div>
      <div className={`text-[32px] text-${color}-900 mb-1`}>{value}</div>
      {description && <p className="text-xs text-gray-600">{description}</p>}
    </Card>
  );
};
