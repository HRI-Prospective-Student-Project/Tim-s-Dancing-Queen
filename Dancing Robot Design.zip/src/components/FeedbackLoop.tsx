import React from 'react';
import { Card } from './ui/card';
import { ArrowRight, ArrowDown, RefreshCw } from 'lucide-react';

export const FeedbackLoop: React.FC = () => {
  return (
    <Card className="p-8 bg-gradient-to-br from-blue-50 via-purple-50 to-green-50">
      <div className="text-center mb-6">
        <h3 className="text-gray-900 mb-2">Continuous Feedback Loop</h3>
        <p className="text-sm text-gray-600">
          The system continuously monitors and adapts based on interaction outcomes
        </p>
      </div>

      <div className="relative">
        {/* Main Flow */}
        <div className="grid grid-cols-3 gap-8 mb-8">
          {/* Sense */}
          <Card className="p-4 bg-blue-100 border-2 border-blue-300">
            <h4 className="text-blue-900 mb-2">SENSE</h4>
            <ul className="text-xs text-blue-800 space-y-1">
              <li>• Audio input</li>
              <li>• Visual detection</li>
              <li>• Human triggers</li>
            </ul>
          </Card>

          {/* Think */}
          <Card className="p-4 bg-purple-100 border-2 border-purple-300">
            <h4 className="text-purple-900 mb-2">THINK</h4>
            <ul className="text-xs text-purple-800 space-y-1">
              <li>• Keyword matching</li>
              <li>• State management</li>
              <li>• Decision making</li>
            </ul>
          </Card>

          {/* Act */}
          <Card className="p-4 bg-green-100 border-2 border-green-300">
            <h4 className="text-green-900 mb-2">ACT</h4>
            <ul className="text-xs text-green-800 space-y-1">
              <li>• Speech output</li>
              <li>• Gestures</li>
              <li>• Sound effects</li>
            </ul>
          </Card>
        </div>

        {/* Arrows */}
        <div className="absolute top-[20%] left-1/3 -translate-x-1/2">
          <ArrowRight className="w-8 h-8 text-blue-600" />
        </div>
        <div className="absolute top-[20%] left-2/3 -translate-x-1/2">
          <ArrowRight className="w-8 h-8 text-purple-600" />
        </div>

        {/* Feedback Loops */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="p-4 bg-yellow-50 border-2 border-yellow-300">
            <div className="flex items-center gap-2 mb-2">
              <RefreshCw className="w-4 h-4 text-yellow-700" />
              <h4 className="text-yellow-900">Output → Sense Feedback</h4>
            </div>
            <p className="text-xs text-yellow-800">
              Robot's actions affect environment and student responses, which are then sensed again (e.g., student responds to greeting)
            </p>
          </Card>

          <Card className="p-4 bg-orange-50 border-2 border-orange-300">
            <div className="flex items-center gap-2 mb-2">
              <RefreshCw className="w-4 h-4 text-orange-700" />
              <h4 className="text-orange-900">Continuous Monitoring</h4>
            </div>
            <p className="text-xs text-orange-800">
              System constantly monitors for: response detection, goodbye keywords, new person detection, error conditions
            </p>
          </Card>
        </div>
      </div>
    </Card>
  );
};
