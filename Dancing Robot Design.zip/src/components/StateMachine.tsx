import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ArrowRight } from 'lucide-react';

interface State {
  id: string;
  name: string;
  description: string;
  color: string;
}

interface Transition {
  from: string;
  to: string;
  condition: string;
  color: string;
}

interface StateMachineProps {
  states: State[];
  transitions: Transition[];
}

export const StateMachine: React.FC<StateMachineProps> = ({ states, transitions }) => {
  return (
    <div className="space-y-6">
      {/* States */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {states.map((state) => (
          <Card
            key={state.id}
            className={`p-4 text-center border-2 bg-${state.color}-50 border-${state.color}-300`}
          >
            <div className={`inline-flex px-3 py-1 rounded-full bg-${state.color}-200 text-${state.color}-800 mb-2`}>
              {state.name}
            </div>
            <p className="text-xs text-gray-600">{state.description}</p>
          </Card>
        ))}
      </div>

      {/* Transitions */}
      <div className="space-y-3">
        <h4 className="text-gray-900">State Transitions</h4>
        {transitions.map((trans, idx) => (
          <div key={idx} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <Badge variant="outline" className="min-w-[100px]">
              {states.find(s => s.id === trans.from)?.name}
            </Badge>
            <ArrowRight className={`w-5 h-5 text-${trans.color}-600`} />
            <Badge variant="outline" className="min-w-[100px]">
              {states.find(s => s.id === trans.to)?.name}
            </Badge>
            <span className="text-sm text-gray-600 flex-1">{trans.condition}{trans.condition === 'Human trigger' ? ' for dance & music' : ''}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
