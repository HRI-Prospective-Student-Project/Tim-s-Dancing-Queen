import React from 'react';
import { ArrowDown, ArrowRight } from 'lucide-react';

interface DataFlowArrowProps {
  label?: string;
  direction?: 'down' | 'right';
  animated?: boolean;
}

export const DataFlowArrow: React.FC<DataFlowArrowProps> = ({
  label,
  direction = 'down',
  animated = true,
}) => {
  const Icon = direction === 'down' ? ArrowDown : ArrowRight;
  
  return (
    <div className={`flex items-center justify-center gap-2 ${
      direction === 'down' ? 'flex-col my-4' : 'flex-row mx-4'
    }`}>
      <div className={`flex items-center gap-2 ${animated ? 'animate-pulse' : ''}`}>
        <Icon className="w-6 h-6 text-blue-500" />
        {label && (
          <span className="text-sm text-gray-600 px-2 py-1 bg-blue-50 rounded">
            {label}
          </span>
        )}
      </div>
    </div>
  );
};
