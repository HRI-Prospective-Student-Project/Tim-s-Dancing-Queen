import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { LucideIcon } from 'lucide-react';

interface ArchitectureNodeProps {
  icon: LucideIcon;
  title: string;
  description: string;
  technologies?: string[];
  color: string;
  onClick?: () => void;
  isActive?: boolean;
}

export const ArchitectureNode: React.FC<ArchitectureNodeProps> = ({
  icon: Icon,
  title,
  description,
  technologies,
  color,
  onClick,
  isActive = false,
}) => {
  return (
    <Card
      className={`p-4 cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
        isActive ? `border-${color}-500 shadow-lg` : 'border-gray-200'
      }`}
      onClick={onClick}
    >
      <div className="flex items-start gap-3">
        <div className={`p-2 rounded-lg bg-${color}-100`}>
          <Icon className={`w-5 h-5 text-${color}-600`} />
        </div>
        <div className="flex-1">
          <h4 className="mb-1">{title}</h4>
          <p className="text-gray-600 text-sm mb-2">{description}</p>
          {technologies && technologies.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {technologies.map((tech, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {tech}
                </Badge>
              ))}
            </div>
          )}
        </div>
      </div>
    </Card>
  );
};
