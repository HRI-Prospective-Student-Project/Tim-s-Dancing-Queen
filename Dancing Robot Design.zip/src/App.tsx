import React, { useState } from 'react';
import { Card } from './components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Badge } from './components/ui/badge';
import { Button } from './components/ui/button';
import { Alert, AlertDescription } from './components/ui/alert';
import { Progress } from './components/ui/progress';
import { StateMachine } from './components/StateMachine';
import { SequenceDiagram } from './components/SequenceDiagram';
import { FeedbackLoop } from './components/FeedbackLoop';
import { StatCard } from './components/DashboardStats';
import {
  Camera,
  Mic,
  User,
  MessageSquare,
  Database,
  Speaker,
  Music,
  Bot,
  AlertCircle,
  CheckCircle2,
  ArrowDown,
  ArrowRight,
  Play,
  Frown,
  Smile,
  Search,
  Volume2,
  Hand,
  Eye,
  Brain,
  Zap,
  Info,
  MousePointer,
  WifiOff,
  Target,
  Clock,
  Users,
  ListChecks,
  TrendingUp,
  FileText,
  Shield,
  Workflow,
  Download,
} from 'lucide-react';

export default function App() {
  const [activeFlow, setActiveFlow] = useState<number>(0);
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);

  const handleDownloadPDF = () => {
    window.print();
  };

  const interactionFlows = [
    {
      title: 'Grab Attention & Initial Contact',
      steps: [
        { phase: 'Human Control', action: 'Operator triggers dance and music through Misty interface', icon: Play, color: 'orange' },
        { phase: 'Sense', action: 'Camera detects person approaching', icon: Camera, color: 'blue' },
        { phase: 'Act', action: 'Greet: "Hello! Welcome to Franklin & Marshall!"', icon: Speaker, color: 'green' },
        { phase: 'Sense', action: 'Wait for response (5 seconds)', icon: Mic, color: 'blue' },
        { phase: 'Think', action: 'Check: Did person respond?', icon: Brain, color: 'purple' },
        { phase: 'Act', action: 'If YES → Continue to intro | If NO → Sad gesture (arms down, sad sound)', icon: Frown, color: 'green' },
      ],
      dialogue: [
        { speaker: 'Misty', text: '*dances and plays music*' },
        { speaker: 'Misty', text: 'Hello! Welcome to Franklin & Marshall!' },
        { speaker: 'Student', text: 'Oh hi! What are you?' },
        { speaker: 'Misty', text: 'I\'m Misty, your campus guide robot! I can answer questions about F&M. What would you like to know?' },
      ]
    },
    {
      title: 'Question & Answer Interaction',
      steps: [
        { phase: 'Act', action: 'Ask: "What questions do you have about F&M?"', icon: MessageSquare, color: 'green' },
        { phase: 'Sense', action: 'Listen and transcribe speech to text', icon: Mic, color: 'blue' },
        { phase: 'Think', action: 'Search transcribed text for keywords', icon: Search, color: 'purple' },
        { phase: 'Think', action: 'Match keyword to hardcoded question database', icon: Database, color: 'purple' },
        { phase: 'Act', action: 'If MATCH → Say answer | If NO MATCH → Apologize and direct to staff', icon: Speaker, color: 'green' },
        { phase: 'Act', action: 'Ask: "Any other questions?"', icon: MessageSquare, color: 'green' },
      ],
      dialogue: [
        { speaker: 'Misty', text: 'What questions do you have about F&M?' },
        { speaker: 'Student', text: 'What majors do you offer?' },
        { speaker: 'System', text: '[Keyword detected: "majors"]' },
        { speaker: 'Misty', text: 'F&M offers over 40 majors including Biology, Computer Science, Economics, Psychology, and more! We also have interdisciplinary programs.' },
        { speaker: 'Misty', text: 'Any other questions?' },
      ]
    },
    {
      title: 'Unable to Answer Scenario',
      steps: [
        { phase: 'Sense', action: 'Listen to student question', icon: Mic, color: 'blue' },
        { phase: 'Think', action: 'Search for keywords in database', icon: Search, color: 'purple' },
        { phase: 'Think', action: 'No matching keyword found', icon: AlertCircle, color: 'purple' },
        { phase: 'Act', action: 'Apologize and gesture toward staff member', icon: Hand, color: 'green' },
      ],
      dialogue: [
        { speaker: 'Student', text: 'What\'s the process for study abroad applications?' },
        { speaker: 'System', text: '[No keyword match found]' },
        { speaker: 'Misty', text: 'I\'m sorry, I don\'t have that information. Let me direct you to one of our admission counselors over there *gestures* who can help you better!' },
      ]
    },
    {
      title: 'Ending Conversation',
      steps: [
        { phase: 'Sense', action: 'Listen for "bye" related keywords', icon: Mic, color: 'blue' },
        { phase: 'Think', action: 'Detect keywords: "bye", "thanks", "goodbye", "see you"', icon: Search, color: 'purple' },
        { phase: 'Act', action: 'Say: "Goodbye! Hope to see you at F&M!"', icon: Speaker, color: 'green' },
        { phase: 'Think', action: 'Reset conversation state', icon: Brain, color: 'purple' },
        { phase: 'Sense', action: 'Ready to detect new person (don\'t re-greet same person)', icon: Camera, color: 'blue' },
      ],
      dialogue: [
        { speaker: 'Student', text: 'Thanks for your help! Bye!' },
        { speaker: 'System', text: '[Keyword detected: "bye"]' },
        { speaker: 'Misty', text: 'Goodbye! Hope to see you at F&M! *waves*' },
        { speaker: 'System', text: '[Reset - Ready for new interaction]' },
      ]
    }
  ];

  const senseComponents = [
    {
      id: 'microphone',
      icon: Mic,
      title: 'Microphone (Audio Input)',
      inputs: ['Audio stream from student speech'],
      outputs: ['Transcribed text'],
      technology: 'Misty built-in speech recognition API',
      limitations: [
        'Speech recognition accuracy may vary with background noise',
        'May not transcribe correctly in crowded environments',
        'Limited to English language support'
      ],
      evidence: 'Tested with Misty\'s CaptureSpeech API - works best in quiet environments at 1-2 meter distance',
    },
    {
      id: 'camera',
      icon: Camera,
      title: 'Camera (Person Detection)',
      inputs: ['RGB camera feed from Misty'],
      outputs: ['Boolean: Person detected (true/false)', 'Person position in frame'],
      technology: 'Misty face detection API or computer vision',
      limitations: [
        'May detect same person multiple times',
        'Difficult to distinguish between different individuals',
        'Performance varies with lighting conditions'
      ],
      evidence: 'Using Misty StartFaceDetection - returns detection events when faces are found',
    },
    {
      id: 'human-control',
      icon: MousePointer,
      title: 'Human Operator (Manual Control)',
      inputs: ['Button clicks/commands via Misty API or Skill Runner'],
      outputs: ['Trigger signals for dance, music, initial greeting'],
      technology: 'Misty Skill Runner web interface or REST API',
      limitations: [
        'Requires human presence and attention',
        'May have delays in response time',
        'Limited scalability for multiple simultaneous interactions'
      ],
      evidence: 'Successfully tested manual control via Misty API for triggering pre-programmed movements',
    },
  ];

  const thinkComponents = [
    {
      id: 'keyword-search',
      icon: Search,
      title: 'Keyword Search Engine',
      inputs: ['Transcribed text from student question'],
      outputs: ['Matched question ID or null if no match'],
      technology: 'Simple string matching algorithm (JavaScript includes() or regex)',
      limitations: [
        'Cannot handle complex questions or variations',
        'May miss questions phrased differently',
        'No context understanding - purely keyword-based'
      ],
      evidence: 'Prototype using JavaScript: if(text.includes("major")) return questionDB["majors"]',
    },
    {
      id: 'question-database',
      icon: Database,
      title: 'Hardcoded Question Database',
      inputs: ['Question ID from keyword search'],
      outputs: ['Pre-written answer text'],
      technology: 'JSON object or JavaScript Map with question-answer pairs',
      limitations: [
        'Static content - cannot generate new answers',
        'Limited to pre-programmed Q&A pairs',
        'Requires manual updates for new questions'
      ],
      evidence: 'Created initial database with 15 common F&M questions (majors, housing, athletics, etc.)',
    },
    {
      id: 'conversation-state',
      icon: Brain,
      title: 'Conversation State Manager',
      inputs: ['Current interaction phase', 'Response/no-response detection', 'Goodbye keywords'],
      outputs: ['Next action command', 'Reset signal'],
      technology: 'State machine (JavaScript switch/case or if-else logic)',
      limitations: [
        'Simple linear conversation flow',
        'Cannot handle interruptions or complex dialogues',
        'Limited memory of conversation history'
      ],
      evidence: 'State machine with 4 states: GREETING → INTRO → Q&A → GOODBYE',
    },
  ];

  const actComponents = [
    {
      id: 'speech-output',
      icon: Speaker,
      title: 'Speech Output (Text-to-Speech)',
      inputs: ['Text string to speak'],
      outputs: ['Audio output through Misty\'s speakers'],
      technology: 'Misty Speak API with built-in TTS',
      limitations: [
        'Limited voice customization options',
        'May sound robotic',
        'Volume may not be suitable for noisy environments'
      ],
      evidence: 'Using Misty.Speak() - tested various phrases, works reliably',
    },
    {
      id: 'gestures',
      icon: Hand,
      title: 'Gestures & Movements',
      inputs: ['Gesture command (wave, sad, point, etc.)'],
      outputs: ['Motor movements (arms, head)', 'LED changes'],
      technology: 'Misty MoveArms, MoveHead, and ChangeLED APIs',
      limitations: [
        'Limited range of motion',
        'Pre-programmed gestures only',
        'Movements may be too subtle to notice'
      ],
      evidence: 'Created 5 gestures: wave (greeting), sad (arms down + blue LED), point (arm extension), nod (head movement)',
    },
    {
      id: 'sound-effects',
      icon: Volume2,
      title: 'Sound Effects & Music',
      inputs: ['Sound/music file name'],
      outputs: ['Audio playback'],
      technology: 'Misty PlayAudio API with uploaded sound files',
      limitations: [
        'Limited storage for audio files',
        'Cannot generate dynamic sounds',
        'May conflict with speech output'
      ],
      evidence: 'Uploaded 3 audio files: upbeat music (greeting), sad sound (no response), goodbye jingle',
    },
  ];

  const assumptions = [
    'The robot will not try to greet the same people after the conversation is over',
    'Questions will mainly be F&M (Franklin & Marshall) related',
    'Robot greets first, which kicks off the conversation',
    'Human operator is available to trigger initial dance and music',
    'Students will speak clearly and at a reasonable volume',
    'Environment has moderate noise levels (not too loud)',
    'Internet connection is available for Misty API calls',
  ];

  const questionExamples = [
    { keywords: ['major', 'majors', 'program', 'study'], answer: 'F&M offers over 40 majors including Biology, Computer Science, Economics, Psychology, English, and more! We also have interdisciplinary programs.' },
    { keywords: ['housing', 'dorm', 'residence', 'live'], answer: 'F&M has various housing options including traditional residence halls, college houses, and apartments. First-year students typically live in our residence halls.' },
    { keywords: ['athletics', 'sports', 'team'], answer: 'F&M competes in NCAA Division III and offers 27 varsity sports teams. We also have club sports and intramural programs!' },
    { keywords: ['campus', 'size', 'location'], answer: 'Our beautiful campus is located in Lancaster, Pennsylvania, about 60 miles west of Philadelphia. The campus spans over 220 acres.' },
    { keywords: ['admission', 'apply', 'requirements'], answer: 'F&M has a holistic admission process. We consider your academic record, extracurriculars, essays, and recommendations. Check out the admissions table for more details!' },
  ];

  const states = [
    { id: 'idle', name: 'IDLE', description: 'Waiting for human trigger or person detection', color: 'gray' },
    { id: 'greeting', name: 'GREETING', description: 'Initial contact with student', color: 'blue' },
    { id: 'intro', name: 'INTRO', description: 'Introducing capabilities', color: 'purple' },
    { id: 'qa', name: 'Q&A', description: 'Answering questions', color: 'green' },
    { id: 'goodbye', name: 'GOODBYE', description: 'Ending conversation', color: 'orange' },
  ];

  const transitions = [
    { from: 'idle', to: 'greeting', condition: 'Person detected OR human trigger', color: 'blue' },
    { from: 'greeting', to: 'intro', condition: 'Student responds to greeting', color: 'purple' },
    { from: 'greeting', to: 'idle', condition: 'No response after 5 seconds (sad gesture)', color: 'gray' },
    { from: 'intro', to: 'qa', condition: 'Robot asks "What questions do you have?"', color: 'green' },
    { from: 'qa', to: 'qa', condition: 'Answer given → "Any other questions?"', color: 'green' },
    { from: 'qa', to: 'goodbye', condition: 'Goodbye keyword detected', color: 'orange' },
    { from: 'goodbye', to: 'idle', condition: 'Conversation reset complete', color: 'gray' },
  ];

  const sequenceSteps = [
    { actor: 'Human Operator', component: 'Misty API', action: 'Trigger dance & music', data: 'PlayAudio("welcome.mp3")', time: '0:00' },
    { actor: 'Misty', component: 'Camera', action: 'Detect person approaching', data: 'FaceDetection: true', time: '0:05' },
    { actor: 'Misty', component: 'Speaker', action: 'Greet student', data: 'Speak("Hello! Welcome to F&M!")', time: '0:06' },
    { actor: 'Student', component: 'Microphone', action: 'Responds to greeting', data: 'Audio: "Hi, what are you?"', time: '0:08' },
    { actor: 'Misty', component: 'Speech Recognition', action: 'Transcribe speech', data: 'Text: "Hi, what are you?"', time: '0:09' },
    { actor: 'Misty', component: 'Speaker', action: 'Introduce self', data: 'Speak("I\'m Misty! I can answer questions...")', time: '0:10' },
    { actor: 'Student', component: 'Microphone', action: 'Asks question', data: 'Audio: "What majors do you offer?"', time: '0:15' },
    { actor: 'Misty', component: 'Keyword Search', action: 'Search for keywords', data: 'Keywords found: ["majors"]', time: '0:16' },
    { actor: 'Misty', component: 'Question DB', action: 'Retrieve answer', data: 'Answer: "F&M offers over 40 majors..."', time: '0:16' },
    { actor: 'Misty', component: 'Speaker', action: 'Provide answer', data: 'Speak answer + "Any other questions?"', time: '0:17' },
    { actor: 'Student', component: 'Microphone', action: 'Says goodbye', data: 'Audio: "Thanks! Bye!"', time: '0:45' },
    { actor: 'Misty', component: 'Keyword Search', action: 'Detect goodbye', data: 'Keywords: ["thanks", "bye"]', time: '0:46' },
    { actor: 'Misty', component: 'Speaker + Gesture', action: 'Wave goodbye', data: 'Speak("Goodbye!") + MoveArms(wave)', time: '0:47' },
    { actor: 'Misty', component: 'State Manager', action: 'Reset to IDLE', data: 'State: IDLE, Ready for new person', time: '0:50' },
  ];

  const deploymentChecklist = [
    { category: 'Pre-Event Setup', items: [
      'Upload all audio files (music, sad sound, goodbye jingle)',
      'Load question-answer database with 30-35 F&M questions',
      'Test all gestures (wave, sad, point, nod)',
      'Calibrate face detection in event lighting conditions',
      'Test speech recognition with background noise',
      'Configure human operator controls',
      'Charge Misty battery to 100%',
      'Prepare backup battery',
    ]},
    { category: 'Day-of Setup', items: [
      'Position Misty in quieter area away from main traffic',
      'Test WiFi connectivity and Misty API access',
      'Brief human operator on trigger controls',
      'Run system diagnostics (sensors, audio, motors)',
      'Place signage explaining Misty\'s capabilities',
      'Identify nearby staff for question referrals',
    ]},
    { category: 'During Event', items: [
      'Monitor battery levels (swap if below 30%)',
      'Track failed speech recognition instances',
      'Note questions not in database',
      'Watch for technical issues',
      'Collect student feedback',
    ]},
    { category: 'Post-Event', items: [
      'Download interaction logs',
      'Analyze most common questions asked',
      'Review failed keyword matches',
      'Document technical issues',
      'Update database based on missing questions',
    ]},
  ];

  const ComponentDetails = ({ component }: { component: any }) => (
    <Card className="p-6 border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white">
      <div className="flex items-start gap-4 mb-4">
        <div className="p-3 bg-blue-100 rounded-lg">
          <component.icon className="w-6 h-6 text-blue-600" />
        </div>
        <div className="flex-1">
          <h3 className="text-gray-900 mb-2">{component.title}</h3>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setSelectedComponent(null)}>
          Close
        </Button>
      </div>

      <div className="space-y-4">
        <div>
          <h4 className="mb-2 text-gray-900">Inputs</h4>
          <ul className="space-y-1">
            {component.inputs.map((input: string, idx: number) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                <ArrowRight className="w-4 h-4 mt-0.5 text-blue-600 flex-shrink-0" />
                <span>{input}</span>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="mb-2 text-gray-900">Outputs</h4>
          <ul className="space-y-1">
            {component.outputs.map((output: string, idx: number) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                <ArrowRight className="w-4 h-4 mt-0.5 text-green-600 flex-shrink-0" />
                <span>{output}</span>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="mb-2 text-gray-900">Technology</h4>
          <Badge variant="secondary" className="text-sm">
            {component.technology}
          </Badge>
        </div>

        <div>
          <h4 className="mb-2 text-gray-900">Known Limitations</h4>
          <ul className="space-y-2">
            {component.limitations.map((limit: string, idx: number) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                <AlertCircle className="w-4 h-4 mt-0.5 text-orange-600 flex-shrink-0" />
                <span>{limit}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="pt-4 border-t">
          <h4 className="mb-2 text-gray-900">Evidence from Prototyping</h4>
          <p className="text-sm text-gray-700 bg-green-50 p-3 rounded-lg border border-green-200">
            <CheckCircle2 className="w-4 h-4 inline mr-2 text-green-600" />
            {component.evidence}
          </p>
        </div>
      </div>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Bot className="w-12 h-12 text-indigo-600" />
              <div>
                <h1 className="text-gray-900">Dancing Queen Robot - HRI Architecture</h1>
                <p className="text-gray-600 text-sm">
                  Franklin & Marshall Admitted Students Day
                  <br />
                  El, Damien, Yohsuke & Geoffrey
                </p>
              </div>
            </div>
            <Button onClick={handleDownloadPDF} className="no-print flex items-center gap-2">
              <Download className="w-4 h-4" />
              Download PDF
            </Button>
          </div>
          <div className="text-center">
            <Badge variant="outline" className="text-sm">
              Keyword-Based Q&A System
            </Badge>
          </div>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-6 mb-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="flow">Interaction Flow</TabsTrigger>
            <TabsTrigger value="architecture">Architecture</TabsTrigger>
            <TabsTrigger value="components">Components</TabsTrigger>
            <TabsTrigger value="assumptions">Assumptions</TabsTrigger>
            <TabsTrigger value="deployment">Deployment</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Dashboard Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatCard
                icon={Eye}
                label="Sense Components"
                value="3"
                color="blue"
                description="Microphone, Camera, Human Control"
              />
              <StatCard
                icon={Brain}
                label="Think Components"
                value="3"
                color="purple"
                description="Keyword Search, DB, State Manager"
              />
              <StatCard
                icon={Zap}
                label="Act Components"
                value="3"
                color="green"
                description="Speech, Gestures, Sound Effects"
              />
              <StatCard
                icon={Database}
                label="Questions in DB"
                value="30-35"
                color="orange"
                description="F&M specific Q&A pairs"
              />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatCard
                icon={Users}
                label="Expected Interactions"
                value="50-100"
                color="indigo"
                description="Students per day"
              />
              <StatCard
                icon={Clock}
                label="Avg Interaction"
                value="2-4 min"
                color="pink"
                description="Per student conversation"
              />
              <StatCard
                icon={Target}
                label="Success Rate Goal"
                value="75%+"
                color="teal"
                description="Successful Q&A matches"
              />
              <StatCard
                icon={Shield}
                label="Safety Priority"
                value="High"
                color="red"
                description="Human oversight required"
              />
            </div>

            {/* System Overview */}
            <Card className="p-6">
              <h3 className="mb-4 text-gray-900">System Overview</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="mb-3 text-gray-900">Project Goal</h4>
                  <p className="text-sm text-gray-700 mb-4">
                    Deploy Misty robot as an interactive campus guide during F&M's admitted students day 
                    to engage prospective students, answer common questions. The aim is to capture students 
                    attention and interest during the first 10-15 minutes that they are on campus.
                  </p>
                  
                  <h4 className="mb-3 text-gray-900">Technical Approach</h4>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 mt-0.5 text-green-600 flex-shrink-0" />
                      <span>Keyword-based question matching (simple, reliable)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 mt-0.5 text-green-600 flex-shrink-0" />
                      <span>Human-in-the-loop for initial engagement</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 mt-0.5 text-green-600 flex-shrink-0" />
                      <span>Hardcoded Q&A database for consistency</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 mt-0.5 text-green-600 flex-shrink-0" />
                      <span>Deferring complex questions to human staff or student designers</span>
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="mb-3 text-gray-900">Key Features</h4>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center gap-2 mb-1">
                        <Music className="w-4 h-4 text-blue-600" />
                        <span className="text-sm text-blue-900">Engaging Greeting</span>
                      </div>
                      <p className="text-xs text-blue-700">Dance and music to attract attention</p>
                    </div>
                    <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                      <div className="flex items-center gap-2 mb-1">
                        <MessageSquare className="w-4 h-4 text-purple-600" />
                        <span className="text-sm text-purple-900">F&M Q&A</span>
                      </div>
                      <p className="text-xs text-purple-700">Answer questions about majors, housing, athletics, etc.</p>
                    </div>
                    <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-center gap-2 mb-1">
                        <Hand className="w-4 h-4 text-green-600" />
                        <span className="text-sm text-green-900">Expressive Gestures</span>
                      </div>
                      <p className="text-xs text-green-700">Wave, nod, point, and emotional expressions</p>
                    </div>
                    <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <div className="flex items-center gap-2 mb-1">
                        <Users className="w-4 h-4 text-orange-600" />
                        <span className="text-sm text-orange-900">Smart Referrals</span>
                      </div>
                      <p className="text-xs text-orange-700">Direct to human staff when needed</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Feedback Loop */}
            <FeedbackLoop />

            {/* State Machine */}
            <Card className="p-6">
              <h3 className="mb-4 text-gray-900">Conversation State Machine</h3>
              <StateMachine states={states} transitions={transitions} />
            </Card>

            {/* Timeline Sequence */}
            <SequenceDiagram 
              title="Complete Interaction Timeline (Typical 50-second interaction)"
              steps={sequenceSteps}
            />
          </TabsContent>

          {/* Interaction Flow Tab */}
          <TabsContent value="flow" className="space-y-6">
            <Alert className="bg-indigo-50 border-indigo-200">
              <Info className="h-4 w-4 text-indigo-600" />
              <AlertDescription>
                This shows the complete interaction flow from initial contact to conversation end.
                Click through different scenarios to see example dialogues and step-by-step processes.
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
              {interactionFlows.map((flow, idx) => (
                <Button
                  key={idx}
                  variant={activeFlow === idx ? 'default' : 'outline'}
                  onClick={() => setActiveFlow(idx)}
                  className="h-auto py-3 px-4 text-left justify-start"
                >
                  <div>
                    <div className="text-sm">{flow.title}</div>
                  </div>
                </Button>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Flow Steps */}
              <Card className="p-6">
                <h3 className="mb-4 text-gray-900">{interactionFlows[activeFlow].title}</h3>
                <div className="space-y-3">
                  {interactionFlows[activeFlow].steps.map((step, idx) => {
                    const StepIcon = step.icon;
                    const colorClass = step.color === 'blue' ? 'bg-blue-100 text-blue-700 border-blue-300' :
                                      step.color === 'purple' ? 'bg-purple-100 text-purple-700 border-purple-300' :
                                      step.color === 'green' ? 'bg-green-100 text-green-700 border-green-300' :
                                      'bg-orange-100 text-orange-700 border-orange-300';
                    
                    return (
                      <div key={idx}>
                        <div className="flex items-start gap-3">
                          <Badge variant="outline" className={`${colorClass} min-w-[120px] justify-center`}>
                            {step.phase}
                          </Badge>
                          <div className="flex items-start gap-2 flex-1">
                            <StepIcon className="w-4 h-4 mt-1 flex-shrink-0 text-gray-600" />
                            <p className="text-sm text-gray-700">{step.action}</p>
                          </div>
                        </div>
                        {idx < interactionFlows[activeFlow].steps.length - 1 && (
                          <div className="ml-[60px] my-2">
                            <ArrowDown className="w-4 h-4 text-gray-400" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </Card>

              {/* Example Dialogue */}
              <Card className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
                <h3 className="mb-4 text-gray-900">Example Dialogue</h3>
                <div className="space-y-3">
                  {interactionFlows[activeFlow].dialogue.map((line, idx) => (
                    <div
                      key={idx}
                      className={`p-3 rounded-lg ${
                        line.speaker === 'Misty'
                          ? 'bg-indigo-100 border border-indigo-300'
                          : line.speaker === 'Student'
                          ? 'bg-white border border-gray-300'
                          : 'bg-gray-100 border border-gray-300'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        {line.speaker === 'Misty' ? (
                          <Bot className="w-4 h-4 text-indigo-600" />
                        ) : line.speaker === 'Student' ? (
                          <User className="w-4 h-4 text-gray-600" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-gray-500" />
                        )}
                        <span className="text-sm text-gray-900">{line.speaker}</span>
                      </div>
                      <p className="text-sm text-gray-700 ml-6">{line.text}</p>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </TabsContent>

          {/* Architecture Tab */}
          <TabsContent value="architecture" className="space-y-8">
            {/* Architecture Diagram */}
            <Card className="p-8 bg-gradient-to-br from-white to-gray-50">
              <div className="text-center mb-8">
                <h2 className="text-gray-900 mb-2">System Architecture Overview</h2>
                <p className="text-gray-600">Information flow with continuous feedback loop</p>
              </div>

              {/* Sense */}
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-blue-100 rounded-lg">
                    <Eye className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-gray-900">SENSE</h3>
                    <p className="text-sm text-gray-600">Environmental & user input capture</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="p-4 bg-blue-50 border-blue-200 hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedComponent('microphone')}>
                    <div className="flex items-center gap-3 mb-2">
                      <Mic className="w-5 h-5 text-blue-600" />
                      <h4 className="text-gray-900">Microphone</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Audio → Transcribed Text</p>
                    <Badge variant="secondary" className="text-xs">Misty CaptureSpeech API</Badge>
                  </Card>
                  <Card className="p-4 bg-blue-50 border-blue-200 hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedComponent('camera')}>
                    <div className="flex items-center gap-3 mb-2">
                      <Camera className="w-5 h-5 text-blue-600" />
                      <h4 className="text-gray-900">Camera</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Person Detection → Boolean</p>
                    <Badge variant="secondary" className="text-xs">Face Detection API</Badge>
                  </Card>
                  <Card className="p-4 bg-orange-50 border-orange-200 hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedComponent('human-control')}>
                    <div className="flex items-center gap-3 mb-2">
                      <MousePointer className="w-5 h-5 text-orange-600" />
                      <h4 className="text-gray-900">Human Control</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Manual Dance/Music Trigger</p>
                    <Badge variant="secondary" className="text-xs">Skill Runner Interface</Badge>
                  </Card>
                </div>
              </div>

              <div className="flex justify-center my-6">
                <div className="flex flex-col items-center gap-2">
                  <ArrowDown className="w-6 h-6 text-gray-400 animate-pulse" />
                  <Badge variant="secondary">Raw Sensor Data</Badge>
                </div>
              </div>

              {/* Think */}
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-purple-100 rounded-lg">
                    <Brain className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-gray-900">THINK</h3>
                    <p className="text-sm text-gray-600">Processing, matching & decision logic</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="p-4 bg-purple-50 border-purple-200 hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedComponent('keyword-search')}>
                    <div className="flex items-center gap-3 mb-2">
                      <Search className="w-5 h-5 text-purple-600" />
                      <h4 className="text-gray-900">Keyword Search</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Text → Matched Question ID</p>
                    <Badge variant="secondary" className="text-xs">String matching (includes/regex)</Badge>
                  </Card>
                  <Card className="p-4 bg-purple-50 border-purple-200 hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedComponent('question-database')}>
                    <div className="flex items-center gap-3 mb-2">
                      <Database className="w-5 h-5 text-purple-600" />
                      <h4 className="text-gray-900">Question Database</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Hardcoded Q&A Pairs</p>
                    <Badge variant="secondary" className="text-xs">JSON / JavaScript Map</Badge>
                  </Card>
                  <Card className="p-4 bg-purple-50 border-purple-200 hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedComponent('conversation-state')}>
                    <div className="flex items-center gap-3 mb-2">
                      <Workflow className="w-5 h-5 text-purple-600" />
                      <h4 className="text-gray-900">State Manager</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Conversation Flow Control</p>
                    <Badge variant="secondary" className="text-xs">State machine (5 states)</Badge>
                  </Card>
                </div>
              </div>

              <div className="flex justify-center my-6">
                <div className="flex flex-col items-center gap-2">
                  <ArrowDown className="w-6 h-6 text-gray-400 animate-pulse" />
                  <Badge variant="secondary">Action Commands</Badge>
                </div>
              </div>

              {/* Act */}
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-green-100 rounded-lg">
                    <Zap className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-gray-900">ACT</h3>
                    <p className="text-sm text-gray-600">Physical & communicative outputs</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="p-4 bg-green-50 border-green-200 hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedComponent('speech-output')}>
                    <div className="flex items-center gap-3 mb-2">
                      <Speaker className="w-5 h-5 text-green-600" />
                      <h4 className="text-gray-900">Speech Output</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Text-to-Speech (TTS)</p>
                    <Badge variant="secondary" className="text-xs">Misty.Speak() API</Badge>
                  </Card>
                  <Card className="p-4 bg-green-50 border-green-200 hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedComponent('gestures')}>
                    <div className="flex items-center gap-3 mb-2">
                      <Hand className="w-5 h-5 text-green-600" />
                      <h4 className="text-gray-900">Gestures</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Arms, Head, LED Movements</p>
                    <Badge variant="secondary" className="text-xs">MoveArms, MoveHead, ChangeLED</Badge>
                  </Card>
                  <Card className="p-4 bg-green-50 border-green-200 hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedComponent('sound-effects')}>
                    <div className="flex items-center gap-3 mb-2">
                      <Volume2 className="w-5 h-5 text-green-600" />
                      <h4 className="text-gray-900">Sound Effects</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Music & Audio Playback</p>
                    <Badge variant="secondary" className="text-xs">PlayAudio API</Badge>
                  </Card>
                </div>
              </div>

              <div className="flex justify-center my-6">
                <div className="flex flex-col items-center gap-2">
                  <ArrowDown className="w-6 h-6 text-yellow-500 animate-pulse" />
                  <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">Feedback to Environment</Badge>
                </div>
              </div>

              {/* Feedback Note */}
              <Alert className="bg-yellow-50 border-yellow-300">
                <Info className="h-4 w-4 text-yellow-700" />
                <AlertDescription className="text-yellow-900">
                  <strong>Continuous Feedback Loop:</strong> Robot's outputs (speech, gestures) affect the environment and student behavior, 
                  which are then sensed again by the microphone and camera, creating a continuous interaction cycle.
                </AlertDescription>
              </Alert>
            </Card>

            {/* Selected Component Details */}
            {selectedComponent && (
              <ComponentDetails
                component={
                  [...senseComponents, ...thinkComponents, ...actComponents].find(
                    (c) => c.id === selectedComponent
                  )
                }
              />
            )}

            {/* Data Flow Details */}
            <Card className="p-6 bg-gradient-to-br from-indigo-50 to-purple-50 border-2 border-indigo-200">
              <h3 className="mb-4 text-gray-900">Detailed Data Flow</h3>
              <div className="space-y-4">
                <div className="p-4 bg-white rounded-lg border border-blue-200">
                  <h4 className="text-blue-900 mb-2">1. Sensing → Processing</h4>
                  <p className="text-sm text-gray-700">
                    <strong>Audio stream</strong> → Speech recognition → <strong>Transcribed text</strong><br/>
                    <strong>Camera frames</strong> → Face detection → <strong>Boolean (person detected)</strong><br/>
                    <strong>Human button press</strong> → API call → <strong>Trigger event</strong>
                  </p>
                </div>

                <div className="p-4 bg-white rounded-lg border border-purple-200">
                  <h4 className="text-purple-900 mb-2">2. Processing → Decision</h4>
                  <p className="text-sm text-gray-700">
                    <strong>Transcribed text</strong> → Keyword search → <strong>Question ID or null</strong><br/>
                    <strong>Question ID</strong> → Database lookup → <strong>Answer text</strong><br/>
                    <strong>Current state + inputs</strong> → State machine → <strong>Next action command</strong>
                  </p>
                </div>

                <div className="p-4 bg-white rounded-lg border border-green-200">
                  <h4 className="text-green-900 mb-2">3. Decision → Action</h4>
                  <p className="text-sm text-gray-700">
                    <strong>Answer text</strong> → TTS synthesis → <strong>Audio output (speakers)</strong><br/>
                    <strong>Gesture command</strong> → Motor control → <strong>Arm/head movement + LED change</strong><br/>
                    <strong>Sound file name</strong> → Audio player → <strong>Music/sound effect playback</strong>
                  </p>
                </div>

                <div className="p-4 bg-white rounded-lg border border-yellow-200">
                  <h4 className="text-yellow-900 mb-2">4. Action → Environment (Feedback)</h4>
                  <p className="text-sm text-gray-700">
                    <strong>Robot speech</strong> → Student hears → <strong>Student responds</strong> → Captured by microphone<br/>
                    <strong>Robot gesture</strong> → Student sees → <strong>Student reaction</strong> → Detected by camera<br/>
                    This creates a continuous loop where outputs become new inputs.
                  </p>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Components Tab */}
          <TabsContent value="components" className="space-y-6">
            <Alert className="bg-blue-50 border-blue-200">
              <Info className="h-4 w-4 text-blue-600" />
              <AlertDescription>
                Click on any component to see detailed specifications including inputs, outputs, technology stack, limitations, and prototyping evidence.
              </AlertDescription>
            </Alert>

            {/* Sense Components */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Eye className="w-6 h-6 text-blue-600" />
                <h3 className="text-gray-900">Sense Components</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {senseComponents.map((comp) => (
                  <Card
                    key={comp.id}
                    className="p-4 hover:shadow-lg transition-shadow cursor-pointer border-2 border-blue-200"
                    onClick={() => setSelectedComponent(comp.id)}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <comp.icon className="w-5 h-5 text-blue-600" />
                      <h4 className="text-gray-900">{comp.title}</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{comp.technology}</p>
                    <Badge variant="outline" className="text-xs">
                      {comp.limitations.length} limitations
                    </Badge>
                  </Card>
                ))}
              </div>
            </div>

            {/* Think Components */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Brain className="w-6 h-6 text-purple-600" />
                <h3 className="text-gray-900">Think Components</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {thinkComponents.map((comp) => (
                  <Card
                    key={comp.id}
                    className="p-4 hover:shadow-lg transition-shadow cursor-pointer border-2 border-purple-200"
                    onClick={() => setSelectedComponent(comp.id)}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <comp.icon className="w-5 h-5 text-purple-600" />
                      <h4 className="text-gray-900">{comp.title}</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{comp.technology}</p>
                    <Badge variant="outline" className="text-xs">
                      {comp.limitations.length} limitations
                    </Badge>
                  </Card>
                ))}
              </div>
            </div>

            {/* Act Components */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Zap className="w-6 h-6 text-green-600" />
                <h3 className="text-gray-900">Act Components</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {actComponents.map((comp) => (
                  <Card
                    key={comp.id}
                    className="p-4 hover:shadow-lg transition-shadow cursor-pointer border-2 border-green-200"
                    onClick={() => setSelectedComponent(comp.id)}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <comp.icon className="w-5 h-5 text-green-600" />
                      <h4 className="text-gray-900">{comp.title}</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{comp.technology}</p>
                    <Badge variant="outline" className="text-xs">
                      {comp.limitations.length} limitations
                    </Badge>
                  </Card>
                ))}
              </div>
            </div>

            {selectedComponent && (
              <ComponentDetails
                component={
                  [...senseComponents, ...thinkComponents, ...actComponents].find(
                    (c) => c.id === selectedComponent
                  )
                }
              />
            )}

            {/* Question Database Examples */}
            <Card className="p-6 bg-gradient-to-br from-indigo-50 to-purple-50 border-2 border-indigo-200">
              <h3 className="mb-4 text-gray-900">Hardcoded Question Database Examples</h3>
              <p className="text-sm text-gray-600 mb-4">
                These are sample question-answer pairs with their associated keywords. When student speech contains any of these keywords, the corresponding answer is retrieved.
              </p>
              <div className="space-y-4">
                {questionExamples.map((q, idx) => (
                  <div key={idx} className="bg-white p-4 rounded-lg border border-indigo-200">
                    <div className="mb-2">
                      <span className="text-sm text-gray-900">Keywords:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {q.keywords.map((keyword, kidx) => (
                          <Badge key={kidx} variant="secondary" className="text-xs">
                            {keyword}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <span className="text-sm text-gray-900">Answer:</span>
                      <p className="text-sm text-gray-700 mt-1">{q.answer}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          {/* Assumptions Tab */}
          <TabsContent value="assumptions" className="space-y-6">
            <Card className="p-6">
              <h3 className="mb-4 text-gray-900">Project Assumptions</h3>
              <div className="space-y-3">
                {assumptions.map((assumption, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-700">{assumption}</p>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6 border-2 border-orange-200 bg-orange-50">
              <h3 className="mb-4 text-gray-900 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-600" />
                Known Limitations & Challenges
              </h3>
              <div className="space-y-4">
                <div>
                  <h4 className="mb-2 text-gray-900">Speech Recognition</h4>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li className="flex items-start gap-2">
                      <WifiOff className="w-4 h-4 mt-0.5 text-orange-600 flex-shrink-0" />
                      <span>Misty's speech recognition may not transcribe correctly in noisy environments</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <WifiOff className="w-4 h-4 mt-0.5 text-orange-600 flex-shrink-0" />
                      <span>Background noise from other students and activities can interfere</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <WifiOff className="w-4 h-4 mt-0.5 text-orange-600 flex-shrink-0" />
                      <span>Accents or unclear speech may result in incorrect transcription</span>
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="mb-2 text-gray-900">Question Matching</h4>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 mt-0.5 text-orange-600 flex-shrink-0" />
                      <span>Simple keyword matching may miss questions phrased differently</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 mt-0.5 text-orange-600 flex-shrink-0" />
                      <span>Cannot understand context or follow-up questions</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 mt-0.5 text-orange-600 flex-shrink-0" />
                      <span>Limited to pre-programmed questions only</span>
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="mb-2 text-gray-900">Implementation Challenges</h4>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 mt-0.5 text-orange-600 flex-shrink-0" />
                      <span>Still figuring out best way to load and structure hardcoded question-keyword pairs</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 mt-0.5 text-orange-600 flex-shrink-0" />
                      <span>Person detection cannot reliably distinguish between different individuals (may re-greet same person)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 mt-0.5 text-orange-600 flex-shrink-0" />
                      <span>Human operator needed for initial engagement - limits scalability</span>
                    </li>
                  </ul>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-gradient-to-br from-green-50 to-blue-50 border-2 border-green-200">
              <h3 className="mb-4 text-gray-900">Mitigation Strategies</h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 bg-white rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-gray-900 mb-1">Position robot in quieter area</h4>
                    <p className="text-sm text-gray-600">Place Misty away from main foot traffic to reduce background noise</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-white rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-gray-900 mb-1">Expand keyword list</h4>
                    <p className="text-sm text-gray-600">Add synonyms and variations for each question category</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-white rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-gray-900 mb-1">Clear fallback messages</h4>
                    <p className="text-sm text-gray-600">When robot can't answer, politely direct to human staff members</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-white rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-gray-900 mb-1">Test in realistic conditions</h4>
                    <p className="text-sm text-gray-600">Prototype in actual event environment to identify issues early</p>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Deployment Tab */}
          <TabsContent value="deployment" className="space-y-6">
            <Alert className="bg-green-50 border-green-200">
              <Info className="h-4 w-4 text-green-600" />
              <AlertDescription>
                Complete pre-event, day-of, during, and post-event procedures for successful deployment.
              </AlertDescription>
            </Alert>

            {deploymentChecklist.map((section, idx) => (
              <Card key={idx} className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <ListChecks className="w-6 h-6 text-indigo-600" />
                  <h3 className="text-gray-900">{section.category}</h3>
                </div>
                <div className="space-y-2">
                  {section.items.map((item, itemIdx) => (
                    <div key={itemIdx} className="flex items-start gap-3 p-2 hover:bg-gray-50 rounded-lg transition-colors">
                      <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <p className="text-gray-700">{item}</p>
                    </div>
                  ))}
                </div>
              </Card>
            ))}

            {/* Success Metrics */}
            <Card className="p-6 bg-gradient-to-br from-purple-50 to-blue-50 border-2 border-purple-200">
              <h3 className="mb-4 text-gray-900 flex items-center gap-2">
                <TrendingUp className="w-6 h-6 text-purple-600" />
                Success Metrics & Evaluation
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="mb-3 text-gray-900">Quantitative Metrics</h4>
                  <div className="space-y-3">
                    <div className="p-3 bg-white rounded-lg border border-purple-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-900">Total Interactions</span>
                        <Badge>Goal: 50-100</Badge>
                      </div>
                      <Progress value={0} className="h-2" />
                      <p className="text-xs text-gray-600 mt-1">Number of students who engaged with Misty</p>
                    </div>
                    <div className="p-3 bg-white rounded-lg border border-purple-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-900">Successful Q&A Match Rate</span>
                        <Badge>Goal: 75%+</Badge>
                      </div>
                      <Progress value={0} className="h-2" />
                      <p className="text-xs text-gray-600 mt-1">Percentage of questions successfully answered</p>
                    </div>
                    <div className="p-3 bg-white rounded-lg border border-purple-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-900">Avg Interaction Duration</span>
                        <Badge>Goal: 2-4 min</Badge>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">Average time per student conversation</p>
                    </div>
                    <div className="p-3 bg-white rounded-lg border border-purple-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-900">Speech Recognition Accuracy</span>
                        <Badge>Goal: 80%+</Badge>
                      </div>
                      <Progress value={0} className="h-2" />
                      <p className="text-xs text-gray-600 mt-1">Correct transcriptions vs total attempts</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="mb-3 text-gray-900">Qualitative Metrics</h4>
                  <div className="space-y-3">
                    <div className="p-3 bg-white rounded-lg border border-blue-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Smile className="w-4 h-4 text-blue-600" />
                        <span className="text-sm text-blue-900">Student Engagement</span>
                      </div>
                      <p className="text-xs text-gray-700">Observe student reactions, smiles, and interest level</p>
                    </div>
                    <div className="p-3 bg-white rounded-lg border border-blue-200">
                      <div className="flex items-center gap-2 mb-2">
                        <MessageSquare className="w-4 h-4 text-blue-600" />
                        <span className="text-sm text-blue-900">Conversation Quality</span>
                      </div>
                      <p className="text-xs text-gray-700">Naturalness of dialogue and student satisfaction</p>
                    </div>
                    <div className="p-3 bg-white rounded-lg border border-blue-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Shield className="w-4 h-4 text-blue-600" />
                        <span className="text-sm text-blue-900">Safety & Reliability</span>
                      </div>
                      <p className="text-xs text-gray-700">Zero technical failures or safety incidents</p>
                    </div>
                    <div className="p-3 bg-white rounded-lg border border-blue-200">
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="w-4 h-4 text-blue-600" />
                        <span className="text-sm text-blue-900">Feedback Collection</span>
                      </div>
                      <p className="text-xs text-gray-700">Gather student and staff impressions</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Risk Management */}
            <Card className="p-6 border-2 border-red-200 bg-red-50">
              <h3 className="mb-4 text-gray-900 flex items-center gap-2">
                <AlertCircle className="w-6 h-6 text-red-600" />
                Risk Management & Contingencies
              </h3>
              <div className="space-y-3">
                <div className="p-3 bg-white rounded-lg">
                  <h4 className="text-red-900 mb-1">WiFi/Network Failure</h4>
                  <p className="text-sm text-gray-700 mb-2"><strong>Risk:</strong> Misty API calls may fail without internet</p>
                  <p className="text-sm text-gray-700"><strong>Mitigation:</strong> Test connection beforehand, have backup hotspot, pre-load offline capabilities where possible</p>
                </div>
                <div className="p-3 bg-white rounded-lg">
                  <h4 className="text-red-900 mb-1">Battery Depletion</h4>
                  <p className="text-sm text-gray-700 mb-2"><strong>Risk:</strong> Misty runs out of power mid-event</p>
                  <p className="text-sm text-gray-700"><strong>Mitigation:</strong> Fully charge before event, monitor battery levels, have backup battery ready for hot-swap</p>
                </div>
                <div className="p-3 bg-white rounded-lg">
                  <h4 className="text-red-900 mb-1">Speech Recognition Breakdown</h4>
                  <p className="text-sm text-gray-700 mb-2"><strong>Risk:</strong> Excessive noise prevents accurate transcription</p>
                  <p className="text-sm text-gray-700"><strong>Mitigation:</strong> Position in quieter area, have human operator assist with noisy interactions, display text on screen option</p>
                </div>
                <div className="p-3 bg-white rounded-lg">
                  <h4 className="text-red-900 mb-1">Software Crash/Error</h4>
                  <p className="text-sm text-gray-700 mb-2"><strong>Risk:</strong> Skill crashes or Misty becomes unresponsive</p>
                  <p className="text-sm text-gray-700"><strong>Mitigation:</strong> Test thoroughly beforehand, have restart procedure ready, maintain human operator oversight</p>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
