
  # Dancing Robot Design

  This is a code bundle for Dancing Robot Design. The original project is available at https://www.figma.com/design/MCs7szhdSemRtGRN5DOKqU/Dancing-Robot-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  